//
//  TriviaControllerViewController.swift
//  SegundoParcial
//
//  Created by Guest User on 29/10/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class TriviaViewController: UIViewController {
    @IBOutlet weak var QuestionStackView: UIStackView!
    
    @IBOutlet weak var Question1: UILabel!
    @IBOutlet weak var Question2: UILabel!
    @IBOutlet weak var Question3: UILabel!
    @IBOutlet weak var Question4: UILabel!
    @IBOutlet weak var Question5: UILabel!
    
    @IBOutlet weak var Switch1: UISwitch!
    @IBOutlet weak var Switch2: UISwitch!
    @IBOutlet weak var Switch3: UISwitch!
    @IBOutlet weak var Switch4: UISwitch!
    @IBOutlet weak var Switch5: UISwitch!
    
    var correctAnswers = 0
    
    @IBAction func TriviaButtonPressed(_ sender: UIButton) {
        
        correctAnswers = 0
        
        if Switch1.isOn {
            correctAnswers += 1
        }
        
        if Switch2.isOn == false {
            correctAnswers += 1
        }
        
        if Switch3.isOn == false{
            correctAnswers += 1
        }
        
        if Switch4.isOn {
            correctAnswers += 1
        }
        
        if Switch5.isOn == false {
            correctAnswers += 1
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender:
        Any?) {
        if let destino = segue.destination as? ResultadosViewController, segue.identifier == "ResultSegue" {
            if correctAnswers == 5 {
                destino.result = "Felicidades. Tu código es: 123"
            } else {
                destino.result = "Sigue participando"
                // Usario perdedor
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        Question1.text = "La capital de Veracruz es Xalapa: "
        Question2.text = "El carnaval de Veracruz es en septiembre: "
        Question3.text = "Veracruz colinda con Tlaxcala: "
        Question4.text = "La cultura olmeca se desarrolló en Veracruz: "
        Question5.text = "Veracruz tiene menos de 100 municipios: "
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
