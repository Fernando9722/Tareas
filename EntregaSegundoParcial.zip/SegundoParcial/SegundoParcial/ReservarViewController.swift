//
//  ReservarViewController.swift
//  SegundoParcial
//
//  Created by Guest User on 29/10/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class ReservarViewController: UIViewController {
    
    @IBOutlet weak var personasTextLabel1: UILabel!
    @IBOutlet weak var personasLabel2: UILabel!
    @IBOutlet weak var cuponText: UITextField!
    @IBOutlet weak var stepper1: UIStepper!
    @IBOutlet weak var stepper2: UIStepper!
    
    
    let cuponReal = "123"
    var total: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func stepper1Change(_ sender: UIStepper) {
        personasTextLabel1.text = "\(Int(sender.value))"
    }
    
    @IBAction func stepper2Change(_ sender: UIStepper) {
        personasLabel2.text = "\(Int(sender.value))"
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let total = total else {return}
        if let destino = segue.destination as? DescuentoViewController {
            destino.total = total
        }
    }
    
    
    @IBAction func continuarButton(_ sender: UIButton) {
        let cantidadPersonas1 = stepper1.value
        let cantidadPersonas2 = stepper2.value
        let cuponReal = "123"
        var cobro = 0.0
        
        if cantidadPersonas1 > 0.0 {
            cobro = 150.0 * cantidadPersonas1
        }
        
        if cantidadPersonas2 > 0.0 {
            cobro = 180.0 * cantidadPersonas2
        }
        
        if cuponText.text == cuponReal {
            cobro = 0.5 * cobro
        }
        
        // guard let cupon = cuponText.text, cupon.isEmpty == false, cantidadPersonas1 > 0.0, cantidadPersonas2 > 0.0  else {return}
        // var cobro = (150 * cantidadPersonas1) + (180 * cantidadPersonas2)
        // if cuponText.text == cuponReal {
            //Descuento
            // cobro = cobro - (cobro * 0.50)
        // }
        
        total = cobro
        performSegue(withIdentifier: "total", sender: self)
        
    }
    
    
}
