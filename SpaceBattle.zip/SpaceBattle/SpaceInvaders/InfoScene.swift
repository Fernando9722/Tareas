//
//  infoScene.swift
//  Space Battle
//
//  Created by Usuario invitado on 12/4/18.
//

import Foundation
import SpriteKit

class InfoScene : SKScene {
    var label : UILabel!
    var resetButton : UIButton!
    
    override func didMove(to view: SKView) {
        scene?.backgroundColor = UIColor.black // Color de fondo de la pantalla
        
        // Características de la etiqueta para información del juego
        label = UILabel(frame: CGRect(x: 0, y: 0, width: 400, height: 240))
        label.numberOfLines = 0
        label.center = CGPoint(x: view.frame.size.width / 2, y: 240)
        label.text = "Facultad de Ingeniería\n\nAutor: Fernando Martínez\n\nTemas selectos de  programación\n\n2018"
        label.textColor = UIColor.yellow
        label.font = UIFont(name: "Copperplate", size: 25)
        label.textAlignment = NSTextAlignment.center
        self.view?.addSubview(label)
        
        // Características del botón para volver a jugar
        resetButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: 240, height: 50))
        resetButton.center = CGPoint(x: view.frame.size.width / 2, y: 540)
        resetButton.setTitle("Play again", for: .normal)
        resetButton.setTitleColor(UIColor.yellow, for: .normal)
        resetButton.titleLabel?.font = UIFont(name: "Copperplate", size: 30)
        self.view?.addSubview(resetButton)
        resetButton.isEnabled = true
        resetButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside)
    }
    
    @objc func restart() {
        resetButton.removeFromSuperview()
        label.removeFromSuperview()
        self.view?.presentScene(GameScene()) // Presentar la pantalla principal del juego
    }
}
