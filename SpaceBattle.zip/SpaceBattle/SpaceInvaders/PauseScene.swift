//
//  PauseScene.swift
//  SpaceInvaders
//
//  Created by Usuario invitado on 11/29/18.
//

import UIKit
import SpriteKit

class PauseScene: SKScene {
    var restartButton : UIButton!
    var finishButton : UIButton!

    override func didMove(to view: SKView) {
        scene?.backgroundColor = UIColor.black // Color de fondo de la pantalla
        
        restartButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50)) // Creación del boton restart
        finishButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50)) // Creación del botón exit
        restartButton.center = CGPoint(x: 207, y: 240) // Posición del botón restart
        finishButton.center = CGPoint(x: 207, y: 340) // Posición del botón exit
        restartButton.setTitle("Restart", for: .normal)
        restartButton.setTitleColor(UIColor.yellow, for: .normal)
        finishButton.setTitle("Exit", for: .normal)
        finishButton.setTitleColor(UIColor.yellow, for: .normal)
        restartButton.titleLabel?.font = UIFont(name: "Copperplate", size: 30)
        finishButton.titleLabel?.font = UIFont(name: "Copperplate", size: 30)
        self.view?.addSubview(restartButton) // Añadir el botón a la pantalla
        self.view?.addSubview(finishButton) // Añadir el botón a la pantalla
        restartButton.isEnabled = true
        finishButton.isEnabled = true
        restartButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside) // Acción al presionar el botón
        finishButton.addTarget(self, action: #selector(self.exit), for: .touchUpInside) // Acción al presionar el botón
    }
    
    // Función en objective-C para reiniciar el juego
    @objc func restart() {
        restartButton.removeFromSuperview()
        finishButton.removeFromSuperview()
        self.view?.presentScene(GameScene()) // Presentar la pantalla principal del juego
    }
    
    // Función en objective-C para terminar el juego
    @objc func exit() {
        restartButton.removeFromSuperview()
        finishButton.removeFromSuperview()
        self.view?.presentScene(FinalScene()) // Presentar la pantalla de resultados del juego
    }
}
