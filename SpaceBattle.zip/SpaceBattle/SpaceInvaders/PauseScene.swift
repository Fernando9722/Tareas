//
//  PauseScene.swift
//  SpaceInvaders
//
//  Created by Usuario invitado on 11/29/18.
//

import UIKit
import SpriteKit

class PauseScene: SKScene {
    var continueButton : UIButton!
    var finishButton : UIButton!
    var imageView : UIImageView!

    override func didMove(to view: SKView) {
        scene?.backgroundColor = UIColor.black
        
        imageView?.image = UIImage(named: "image2")
        imageView?.contentMode = .scaleAspectFit
        imageView = UIImageView(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        imageView?.center = CGPoint(x: 207, y: 200)

        continueButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        finishButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        continueButton.center = CGPoint(x: 207, y: 440)
        finishButton.center = CGPoint(x: 207, y: 540)
        continueButton.setTitle("Continue", for: .normal)
        continueButton.setTitleColor(UIColor.yellow, for: .normal)
        finishButton.setTitle("Exit", for: .normal)
        finishButton.setTitleColor(UIColor.yellow, for: .normal)
        self.view?.addSubview(continueButton)
        self.view?.addSubview(finishButton)
        continueButton.isEnabled = true
        finishButton.isEnabled = true
        continueButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside)
        finishButton.addTarget(self, action: #selector(self.exit), for: .touchUpInside)
    }
    
    @objc func restart() {
        imageView?.removeFromSuperview()
        continueButton.removeFromSuperview()
        finishButton.removeFromSuperview()
        self.view?.presentScene(GameScene())
    }
    
    @objc func exit() {
        imageView?.removeFromSuperview()
        continueButton.removeFromSuperview()
        finishButton.removeFromSuperview()
        self.view?.presentScene(FinalScene())
    }
}
