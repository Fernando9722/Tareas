//
//  GameScene.swift
//  SpaceInvaders
//
//  Created by Macbook on 11/7/18.
//

import SpriteKit
import GameplayKit
import Foundation
import AVFoundation

// Para las características físicas de los objetos
struct physics {
    static let alien : UInt32 = 1
    static let shot : UInt32 = 2
    static let spaceship : UInt32 = 3
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    var score = 0
    var highScore = 0
    var scoreLabel = UILabel()
    var spaceship = SKSpriteNode(imageNamed: "spaceship") // Dibuja la nave espacial
    var pauseButton : UIButton!
    var backgroundMusic : AVAudioPlayer = AVAudioPlayer()
    var collisionSound : AVAudioPlayer = AVAudioPlayer()
    var crashSound : AVAudioPlayer = AVAudioPlayer()
    var shotSound : AVAudioPlayer = AVAudioPlayer()
    var bulletTimer : Timer = Timer()

    override func didMove(to view: SKView) {
        let bounds = UIScreen.main.bounds // Para las dimensiones de la pantalla
        spaceship.physicsBody = SKPhysicsBody(rectangleOf: spaceship.size) // Creación de la nave como cuerpo físico
        physicsWorld.contactDelegate = self // Físicas del entorno
        self.scene?.size = CGSize(width: bounds.size.width, height: bounds.size.height) // Redimensionar el área de juego
        let highScoreDefault = UserDefaults.standard // Para acceder a la puntuación récord
        
        // Acceder a los récords y si no existen se establece el récord en cero
        if highScoreDefault.value(forKey: "highScore") != nil {
            highScore = highScoreDefault.value(forKey: "highScore") as! Int
        } else {
            highScore = 0
        }
        
        // Música de fondo
        do {
            let background = Bundle.main.path(forResource: "Background", ofType: "mp3")
            try backgroundMusic = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: background!) as URL)
        } catch {
            // Error
        }
        backgroundMusic.play()
        
        // Características de la nave
        spaceship.position = CGPoint(x: self.size.width / 2, y: self.size.height / 8)
        spaceship.physicsBody?.affectedByGravity = false
        spaceship.physicsBody?.categoryBitMask = physics.spaceship // Asignación de la física de la nave
        spaceship.physicsBody?.contactTestBitMask = physics.alien // Asignación de la interacción de la nave
        spaceship.physicsBody?.isDynamic = false // Define si su comportamiento es dinámico
        self.addChild(spaceship)
        self.addChild(SKEmitterNode(fileNamed: "SpaceSimulation")!) // Para el efecto de las estrellas
        
        // Características de la etiqueta para la puntuación actual
        scoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 20))
        scoreLabel.center = CGPoint(x : 40, y : 25)
        scoreLabel.textColor = UIColor.yellow
        scoreLabel.textAlignment = .center
        scoreLabel.text = "Score: \(score)"
        self.view?.addSubview(scoreLabel)
        
        // Características del botón de pausa
        pauseButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        pauseButton.center = CGPoint(x: 365, y: 25)
        pauseButton.setTitle("Pause", for: .normal)
        pauseButton.setTitleColor(UIColor.yellow, for: .normal)
        pauseButton.titleLabel?.font = UIFont(name: "Copperplate", size: 20)
        self.view?.addSubview(pauseButton)
        pauseButton.isEnabled = true
        pauseButton.addTarget(self, action: #selector(self.pause), for: .touchUpInside) // Acción cuando el botón es presionado
        
        // Definición de las características del disparo
        bulletTimer = Timer.scheduledTimer(withTimeInterval: 0.35, repeats: true) { (Timer) in
            let shot = SKSpriteNode(imageNamed: "bullet") // Dibuja la bala
            do {
                let bullet = Bundle.main.path(forResource: "Shot", ofType: "mp3")
                try self.shotSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: bullet!) as URL)
            } catch {
                // Error
            }
            self.shotSound.play()
            
            shot.zPosition = -1 // Para que aparezca detrás de la nave
            shot.position = CGPoint(x: self.spaceship.position.x, y: self.spaceship.position.y) // Posición inicial del disparo en la misma posición de la nave
            let shotMoving = SKAction.moveTo(y: 1500, duration: 1) // Para moverlo en dirección vertical y su velocidad
            let shotMoved = SKAction.removeFromParent() // Para quitarlo de la pantalla cuando termine su recorrido
            shot.run(SKAction.sequence([shotMoving, shotMoved])) // Para realizar las dos acciones anteriores secuencialmente
            shot.physicsBody = SKPhysicsBody(rectangleOf: shot.size) // Creación de la nave como cuerpo físico
            shot.physicsBody?.categoryBitMask = physics.shot // Asignación de la física del disparo
            shot.physicsBody?.contactTestBitMask = physics.alien // Asignación de la interacción del disparo
            shot.physicsBody?.affectedByGravity = false
            shot.physicsBody?.isDynamic = false // Define si su comportamiento es dinámico
            self.addChild(shot)
        }
        
        // Definición de las características del enemigo
        var alienTimer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { (Timer) in
            let alien = SKSpriteNode(imageNamed: "alien") // Dibuja el alien
            alien.position = CGPoint(x: CGFloat(arc4random_uniform(750)), y: 1500) // Posición inicial en un punto horizontal aleatorio
            let alienMoving = SKAction.moveTo(y: -700, duration: 1) // Para moverlo en dirección vertical y su velocidad
            let alienMoved = SKAction.removeFromParent() // Para quitarlo de la pantalla cuando termine su recorrido
            alien.run(SKAction.sequence([alienMoving, alienMoved])) // Para realizar las dos acciones anteriores secuencialmente
            alien.physicsBody = SKPhysicsBody(rectangleOf: alien.size) // Creación del alien como cuerpo físico
            alien.physicsBody?.categoryBitMask = physics.alien // Asignación de la física del alien
            alien.physicsBody?.contactTestBitMask = physics.alien // Asignación de la interacción del alien
            alien.physicsBody?.affectedByGravity = false
            alien.physicsBody?.isDynamic = true // Define si su comportamiento es dinámico
            self.addChild(alien)
        }
    }
    
    // Para detectar las colisiones entre objetos
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody : SKPhysicsBody = contact.bodyA // Primer cuerpo físico
        let secondBody : SKPhysicsBody = contact.bodyB // Segundo cuerpo físico
        
        // Si choca el disparo contra el alien o si choca la nave contra el alien
        if (firstBody.categoryBitMask == physics.alien) && (secondBody.categoryBitMask == physics.shot) || (firstBody.categoryBitMask == physics.shot) && (secondBody.categoryBitMask == physics.alien) {
            alienGotShot(alien: firstBody.node as! SKSpriteNode, shot: secondBody.node as! SKSpriteNode)
        } else if (firstBody.categoryBitMask == physics.alien) && (secondBody.categoryBitMask == physics.spaceship) || (firstBody.categoryBitMask == physics.spaceship) && (secondBody.categoryBitMask == physics.alien) {
            crash(alien: firstBody.node as! SKSpriteNode, spaceship: secondBody.node as! SKSpriteNode)
        }
    }
    
    // Función para la colisión entre el disparo y el alien
    func alienGotShot(alien: SKSpriteNode, shot: SKSpriteNode) {
        do {
            let collision = Bundle.main.path(forResource: "Collision2", ofType: "mp3")
            try collisionSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: collision!) as URL)
        } catch {
            // Error
        }
        collisionSound.play()
        
        alien.removeFromParent() // Quitar alien de la pantalla
        shot.removeFromParent() // Quitar disparo de la pantalla
        score = score + 1 // Incrementar la puntuación
        scoreLabel.text = "\(score)" // Mostrar la puntuación en la etiqueta
    }
    
    // Función para la colisiíon entre el alien y la nave
    func crash(alien: SKSpriteNode, spaceship: SKSpriteNode) {
        do {
            let crash = Bundle.main.path(forResource: "Collision3", ofType: "mp3")
            try crashSound = AVAudioPlayer(contentsOf: NSURL(fileURLWithPath: crash!) as URL)
        } catch {
            // Error
        }
        bulletTimer.invalidate()
        crashSound.play()
        
        let scoreDefault = UserDefaults.standard // Accede a los datos guardados del usuario en varias partidas
        scoreDefault.setValue(score, forKey: "score") // Asignación de la puntuación actual
        scoreDefault.synchronize() // Sincronización de la puntuación
        
        // Nuevo récord
        if score > highScore {
            let highScoreDefault = UserDefaults.standard // Guardar el valor récord en la base de datos
            highScoreDefault.set(score, forKey: "highScore") // Asignar el valor récord
        }
        
        alien.removeFromParent()
        spaceship.removeFromParent()
        scoreLabel.removeFromSuperview()
        pauseButton.removeFromSuperview()
        self.view?.presentScene(FinalScene())
    }
    
    // Cuando el usuario desliza el dedo en la pantalla
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches {
            let location = touch.location(in: self) // Asignación de la variable location a la posición del dedo del usuario
            spaceship.position.x = location.x // Asignación a la posición de la nave
        }
    }
    
    // Función en objective-C para pausar el juego
    @objc func pause() {
        self.view?.isPaused = true // Pausar el movimiento en la pantalla
        scoreLabel.removeFromSuperview()
        pauseButton.removeFromSuperview()
        backgroundMusic.pause()
        bulletTimer.invalidate()

        self.view?.presentScene(PauseScene()) // Presentar la pantalla de pausa
    }

}
