//
//  GameScene.swift
//  SpaceInvaders
//
//  Created by Macbook on 11/7/18.
//

import SpriteKit
import GameplayKit
import Foundation

struct physics {
    static let alien : UInt32 = 1
    static let shot : UInt32 = 2
    static let spaceship : UInt32 = 3
}

class GameScene: SKScene, SKPhysicsContactDelegate {
    var score = 0
    var highScore = 0
    var scoreLabel = UILabel()
    var spaceship = SKSpriteNode(imageNamed: "spaceship")

    override func didMove(to view: SKView) {
        physicsWorld.contactDelegate = self
        let highScoreDefault = UserDefaults.standard
        
        if highScoreDefault.value(forKey: "highScore") != nil {
            highScore = highScoreDefault.value(forKey: "highScore") as! Int
        } else {
            highScore = 0
        }
        
        spaceship.position = CGPoint(x: 375, y: -570)
        spaceship.physicsBody = SKPhysicsBody(rectangleOf: spaceship.size)
        spaceship.physicsBody?.affectedByGravity = false
        spaceship.physicsBody?.categoryBitMask = physics.spaceship
        spaceship.physicsBody?.contactTestBitMask = physics.alien
        spaceship.physicsBody?.isDynamic = false
        self.addChild(spaceship)
        self.addChild(SKEmitterNode(fileNamed: "SpaceSimulation")!)
        
        scoreLabel.text = "\(score)"
        scoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 20))
        scoreLabel.center = CGPoint(x : 400, y : 570)
        scoreLabel.backgroundColor = UIColor(red: 0.1, green: 0.1, blue: 0.1, alpha: 0.3)
        scoreLabel.textColor = UIColor.white
        self.view?.addSubview(scoreLabel)
        
        var bulletTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (Timer) in
            let shot = SKSpriteNode(imageNamed: "shot")
            shot.zPosition = -1
            shot.position = CGPoint(x: self.spaceship.position.x, y: self.spaceship.position.y)
            let shotMoving = SKAction.moveTo(y: 1000, duration: 1.4)
            let shotMoved = SKAction.removeFromParent()
            shot.run(SKAction.sequence([shotMoving, shotMoved]))
            shot.physicsBody = SKPhysicsBody(rectangleOf: shot.size)
            shot.physicsBody?.categoryBitMask = physics.shot
            shot.physicsBody?.contactTestBitMask = physics.alien
            shot.physicsBody?.affectedByGravity = false
            shot.physicsBody?.isDynamic = false
            self.addChild(shot)
        }
        
        var alienTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (Timer) in
            let alien = SKSpriteNode(imageNamed: "alien")
            alien.position = CGPoint(x: CGFloat(arc4random_uniform(750)), y: 700)
            let alienMoving = SKAction.moveTo(y: -700, duration: 1.4)
            let alienMoved = SKAction.removeFromParent()
            alien.run(SKAction.sequence([alienMoving, alienMoved]))
            alien.physicsBody = SKPhysicsBody(rectangleOf: alien.size)
            alien.physicsBody?.categoryBitMask = physics.alien
            alien.physicsBody?.contactTestBitMask = physics.alien
            alien.physicsBody?.affectedByGravity = false
            alien.physicsBody?.isDynamic = true
            
            self.addChild(alien)
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        let firstBody : SKPhysicsBody = contact.bodyA
        let secondBody : SKPhysicsBody = contact.bodyB
        
        if (firstBody.categoryBitMask == physics.alien) && (secondBody.categoryBitMask == physics.shot) || (firstBody.categoryBitMask == physics.shot) && (secondBody.categoryBitMask == physics.alien) {
            alienGotShot(alien: firstBody.node as! SKSpriteNode, shot: secondBody.node as! SKSpriteNode)
        } else if (firstBody.categoryBitMask == physics.alien) && (secondBody.categoryBitMask == physics.spaceship) || (firstBody.categoryBitMask == physics.spaceship) && (secondBody.categoryBitMask == physics.alien) {
            crash(alien: firstBody.node as! SKSpriteNode, spaceship: secondBody.node as! SKSpriteNode)
        }
    }
    
    func alienGotShot(alien: SKSpriteNode, shot: SKSpriteNode) {
        alien.removeFromParent()
        shot.removeFromParent()
        score = score + 1
        scoreLabel.text = "\(score)"
    }
    
    func crash(alien: SKSpriteNode, spaceship: SKSpriteNode) {
        let scoreDefault = UserDefaults.standard
        scoreDefault.setValue(score, forKey: "score")
        scoreDefault.synchronize()
        
        if score > highScore {
            let highScoreDefault = UserDefaults.standard
            highScoreDefault.set(score, forKey: "highScore")
        }
        
        alien.removeFromParent()
        spaceship.removeFromParent()
        self.view?.presentScene(FinalScene())
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches {
            let location = touch.location(in: self)
            spaceship.position.x = location.x
        }
    }

}
