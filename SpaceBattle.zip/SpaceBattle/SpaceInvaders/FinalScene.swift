//
//  FinalScene.swift
//  SpaceBattle
//
//  Created by Guest User on 11/21/18.
//

import Foundation
import SpriteKit

class FinalScene : SKScene {
    var resetButton : UIButton!
    var scoreLabel : UILabel!
    var highScoreLabel : UILabel!
    var image : UIImageView!
    
    override func didMove(to view: SKView) {
        scene?.backgroundColor = UIColor.black
        
        image?.image = UIImage(named: "image3")
        image = UIImageView(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: 200, height: 240))
        image?.center = CGPoint(x: 200, y: view.frame.size.height / 2)
        self.view?.addSubview(image)
        
        resetButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        resetButton.center = CGPoint(x: view.frame.size.width / 2, y: 540)
        resetButton.setTitle("Reset", for: .normal)
        resetButton.setTitleColor(UIColor.yellow, for: .normal)
        self.view?.addSubview(resetButton)
        resetButton.isEnabled = true
        resetButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside)
        
        let scoreDefault = UserDefaults.standard
        let score = scoreDefault.value(forKey: "score")
        
        let highScoreDefault = UserDefaults.standard
        let highScore = highScoreDefault.value(forKey: "highScore")
        
        scoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 30))
        scoreLabel.center = CGPoint(x: view.frame.size.width / 2, y: 340)
        scoreLabel.text = "Score: \(score ?? 0)"
        scoreLabel.textColor = UIColor.yellow
        scoreLabel.textAlignment = NSTextAlignment.center
        self.view?.addSubview(scoreLabel)
        
        highScoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 30))
        highScoreLabel.center = CGPoint(x: view.frame.size.width / 2, y: 440)
        highScoreLabel.text = "High score: \(highScore ?? 0)"
        highScoreLabel.textColor = UIColor.yellow
        highScoreLabel.textAlignment = NSTextAlignment.center
        self.view?.addSubview(highScoreLabel)
    }
    
    @objc func restart() {
        image?.removeFromSuperview()
        resetButton.removeFromSuperview()
        scoreLabel.removeFromSuperview()
        highScoreLabel.removeFromSuperview()
        self.view?.presentScene(GameScene())
    }
}
