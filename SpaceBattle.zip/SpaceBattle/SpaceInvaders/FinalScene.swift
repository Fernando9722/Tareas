//
//  FinalScene.swift
//  SpaceBattle
//
//  Created by Guest User on 11/21/18.
//

import Foundation
import SpriteKit

class FinalScene : SKScene {
    var resetButton : UIButton!
    var infoButton : UIButton!
    var scoreLabel : UILabel!
    var highScoreLabel : UILabel!

    override func didMove(to view: SKView) {
        scene?.backgroundColor = UIColor.black // Color de fondo de la pantalla
        
        // Características del botón reset
        resetButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: 240, height: 50))
        resetButton.center = CGPoint(x: view.frame.size.width / 2, y: 540)
        resetButton.setTitle("Play again", for: .normal)
        resetButton.setTitleColor(UIColor.yellow, for: .normal)
        resetButton.titleLabel?.font = UIFont(name: "Copperplate", size: 30)
        self.view?.addSubview(resetButton)
        resetButton.isEnabled = true
        resetButton.addTarget(self, action: #selector(self.restart), for: .touchUpInside)
        
        // Características del botón info
        infoButton = UIButton(frame: CGRect(x: view.frame.size.width / 2, y: 0, width: view.frame.size.width / 3, height: 50))
        infoButton.center = CGPoint(x: view.frame.size.width / 2, y: 440)
        infoButton.setTitle("Info", for: .normal)
        infoButton.setTitleColor(UIColor.yellow, for: .normal)
        infoButton.titleLabel?.font = UIFont(name: "Copperplate", size: 30)
        self.view?.addSubview(infoButton)
        infoButton.isEnabled = true
        infoButton.addTarget(self, action: #selector(self.info), for: .touchUpInside)
        
        let scoreDefault = UserDefaults.standard // Accede al registro de puntuaciones del usuario
        let score = scoreDefault.value(forKey: "score") // Asigna el valor default a la variable score
        
        let highScoreDefault = UserDefaults.standard // Accede al registro de puntuaciones del usuario
        let highScore = highScoreDefault.value(forKey: "highScore") // Asigna el valor default a la variable highScore
        
        // Características de la etiqueta para la puntuación obtenida
        scoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 30))
        scoreLabel.center = CGPoint(x: view.frame.size.width / 2, y: 240)
        scoreLabel.text = "Score: \(score ?? 0)"
        scoreLabel.textColor = UIColor.yellow
        scoreLabel.font = UIFont(name: "Copperplate", size: 30)
        scoreLabel.textAlignment = NSTextAlignment.center
        self.view?.addSubview(scoreLabel)
        
        // Características de la etiqueta para la puntuación récord
        highScoreLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 240, height: 40))
        highScoreLabel.center = CGPoint(x: view.frame.size.width / 2, y: 340)
        highScoreLabel.text = "High score: \(highScore ?? 0)"
        highScoreLabel.textColor = UIColor.yellow
        highScoreLabel.font = UIFont(name: "Copperplate", size: 30)
        highScoreLabel.textAlignment = NSTextAlignment.center
        self.view?.addSubview(highScoreLabel)
    }
    
    // Función en objective-C para reiniciar el juego
    @objc func restart() {
        resetButton.removeFromSuperview()
        infoButton.removeFromSuperview()
        scoreLabel.removeFromSuperview()
        highScoreLabel.removeFromSuperview()
        self.view?.presentScene(GameScene()) // Presentar la pantalla principal del juego
    }
    
    // Función en objective-C para mostrar la info del juego
    @objc func info() {
        resetButton.removeFromSuperview()
        infoButton.removeFromSuperview()
        scoreLabel.removeFromSuperview()
        highScoreLabel.removeFromSuperview()
        self.view?.presentScene(InfoScene()) // Presentar la pantalla de información del juego
    }
}
