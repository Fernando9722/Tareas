//
//  ViewController.swift
//  RockPaperScissors
//
//  Created by Guest User on 28/9/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var enemyLabel: UILabel!
    @IBOutlet weak var gameStateLabel: UILabel!
    @IBOutlet weak var rockButton: UIButton!
    @IBOutlet weak var paperButton: UIButton!
    @IBOutlet weak var scissorsButton: UIButton!
    @IBOutlet weak var playAgainButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        updateState(gameState: .start)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func TapRockButton(_ sender: UIButton) {
        play(userSign: Sign.rock)
        paperButton.isHidden = true
        scissorsButton.isHidden = true
    }
    
    @IBAction func TapPaperButton(_ sender: UIButton) {
        play(userSign: Sign.paper)
        rockButton.isHidden = true
        scissorsButton.isHidden = true
    }
    
    @IBAction func TapScissorsButton(_ sender: Any) {
        play(userSign: Sign.scissors)
        rockButton.isHidden = true
        paperButton.isHidden = true
    }
    
    @IBAction func PlayAgain(_ sender: Any) {
        updateState(gameState: .start)
    }
    
    func play(userSign: Sign) {
        let enemySign = randomSign()
        enemyLabel.text = enemySign.signValue
        let gameState = userSign.getState(sign: enemySign)
        updateState(gameState: gameState)
        rockButton.isEnabled = false
        paperButton.isEnabled = false
        scissorsButton.isEnabled = false
        playAgainButton.isHidden = false
        playAgainButton.isEnabled = true
    }
    
    func updateState(gameState: GameState) {
        gameStateLabel.text = gameState.status
        
        switch gameState {
        case .start:
            enemyLabel.text = "🧛🏻‍♂️"
            view.backgroundColor = UIColor.blue
            playAgainButton.isHidden = true
            rockButton.isHidden = false
            paperButton.isHidden = false
            scissorsButton.isHidden = false
            rockButton.isEnabled = true
            paperButton.isEnabled = true
            scissorsButton.isEnabled = true
        case .win:
            view.backgroundColor = UIColor.green
        case .lose:
            view.backgroundColor = UIColor.red
        case .draw:
            view.backgroundColor = UIColor.blue
        }
    }

}
