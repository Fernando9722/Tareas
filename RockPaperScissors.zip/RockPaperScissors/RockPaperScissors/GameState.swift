//
//  GameState.swift
//  RockPaperScissors
//
//  Created by Guest User on 28/9/18.
//  Copyright © 2018 Guest User. All rights reserved.
//

import Foundation

enum GameState {
    case start
    case win
    case lose
    case draw
    
    var status: String {
        switch self {
        case .start:
            return "Select an option:"
        case .win:
            return "You're the winner!"
        case .lose:
            return "You're a looser!"
        case .draw:
            return "Draw!"
        }
    }
}
