//: Playground - noun: a place where people can play

import UIKit

struct MyQuestionAnswerer {
    func responseTo(question: String) -> String {
        if(question.hasPrefix("Como")){
            return "Tu pregunta es muy compleja"
        }
        if(question.hasPrefix("Donde")){
            return "Busca en tu imaginación"
        }
        if(question.hasPrefix("Que")){
            return "No existe una respuesta para eso"
        }
        if(question.hasPrefix("Quien")){
            return "No creerías la respuesta"
        }
        if(question.hasPrefix("Cuando")){
            return "Estás bromeando?"
        }
        return "Sólo soy un robot"
    }
}

