import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

extension URL {
    func withQueries(_ queries : [String : String]) -> URL? {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: true)
        components?.queryItems = queries.map{
            URLQueryItem(name: $0.0, value: $0.1)
        }
        
        return components?.url
    }
}

let baseURL = URL(string: "https://api.nasa.gov/planetary/apod")! // Cuando tenemos la seguridad de que es una URL
let query : [String : String] = [
    "api_key" : "XMnvTh3FkG7HQDfjFgfYZuBc49sWdQozyrBsMNqQ", "date" : "2011-07-13"
]
 
/*let baseURL = URL(string: "https://itunes.apple.com/lookup/")! // Cuando tenemos la seguridad de que es una URL
let query : [String : String] = [
    "amgArtistId" : "468749,5723",
    "entity" : "album",
    "limit" : "5"
]*/

struct NasaPhoto : Codable {
    var date : String
    var title : String
    var explanation : String
    var url : String
    
    enum CodingKeys : String, CodingKey {
        case date
        case title
        case explanation
        case url
    }
}
 
let url = baseURL.withQueries(query)!

let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
    if let data  = data,
        let string = String(data : data, encoding : .utf8) {
        // print(data as? NSData)
        print(string)
    }
}

task.resume()


