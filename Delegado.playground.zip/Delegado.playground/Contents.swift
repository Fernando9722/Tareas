//: Playground - noun: a place where people can play

import Foundation

class Button{
    let title: String
    var delegate: ButtonDelegate? // Opcional
    
    init(title: String){
        self.title = title
    }
    
    func tapped() {
        self.delegate?.userTappedButton(self)
    }
}

protocol ButtonDelegate {
    func userTappedButton(_ button: Button)
}

class Song {
    var title: String
    init(title: String){
        self.title = title
    }
}

class MusicController: ButtonDelegate {
    func userTappedButton(_ button: Button) {
        if button.title == "Play" {
            playSong(playlist.first!)
        } else if button.title == "Pause" {
            pauseSong()
        }
    }
    
    func playSong(_ song: Song){
        print("Now playing \(song.title)")
    }
    
    func pauseSong() {
        print("Paused current song")
    }
}

let playlist: [Song] = [Song(title: "Get me"), Song(title: "Come to me"), Song(title: "Let it be")]

let musicController = MusicController()

let startMusicButton = Button(title: "Play")
let pauseMusicButton = Button(title: "Pause")

startMusicButton.delegate = musicController

startMusicButton.tapped()
pauseMusicButton.tapped()

