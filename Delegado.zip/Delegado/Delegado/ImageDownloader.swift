//
//  ImageDownloader.swift
//  Delegado
//
//  Created by Usuario invitado on 22/10/18.
//

import UIKit
import Foundation

class ImageDownloader {
    var imageURL: String
    var image: UIImage?
    var view: ViewController
    
    init(imageURL: String, view: ViewController) {
        self.imageURL = imageURL
        self.view = view
    }
    
    func downloadImage() {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).async {
            guard
                let imageURLUnwrapped = URL(string: self.imageURL),
                let imageData = NSData(contentsOf: imageURLUnwrapped),
                let image = UIImage(data: imageData as Data)
                else {
                    return
            }
        }
    }
    
    func didDownloadImage() {
        // Una vez que se bajó
    }
}
