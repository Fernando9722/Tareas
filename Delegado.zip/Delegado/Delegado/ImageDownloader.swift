//
//  ImageDownloader.swift
//  Delegado
//
//  Created by Usuario invitado on 22/10/18.
//

import UIKit
import Foundation

class ImageDownloader {
    var imageURL: String
    var image: UIImage?
    var delegate: ImageDownloaderDelegate?
    
    init(imageURL: String) {
        self.imageURL = imageURL
    }
    
    func downloadImage() {
        DispatchQueue.global(qos: DispatchQoS.QoSClass.background).async {
            guard
                let imageURLUnwrapped = URL(string: self.imageURL),
                let imageData = NSData(contentsOf: imageURLUnwrapped),
                let image = UIImage(data: imageData as Data)
                else {
                    return
                }
            
                self.image = image
                print("Image downloaded and set in the instance")
            
                DispatchQueue.main.async {
                    self.didDownloadImage()
                }
        }
    }
    
    func didDownloadImage() {
        print("Now how change the properties of the ViewController?")
        delegate?.didFinishDownload(self)
    }
}
