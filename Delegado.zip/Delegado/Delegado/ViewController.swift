//
//  ViewController.swift
//  Delegado
//
//  Created by Usuario invitado on 22/10/18.
//

import UIKit

class ViewController: UIViewController, ImageDownloaderDelegate {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var loadingLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var imageDownloader: ImageDownloader?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.isHidden = true
        loadingLabel.isHidden = true
        let imageURL: String = "https://cdn.spacetelescope.org/archives/images/publicationjpg/heic1509a.jpg"
        imageDownloader = ImageDownloader(imageURL: imageURL)
        imageDownloader?.delegate = self
        imageDownloader?.downloadImage()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func didFinishDownload(_ sender: ImageDownloader) {
        imageView.image = sender.image
        imageView.isHidden = false
        loadingLabel.isHidden = false
        activityIndicator.isHidden = true
        loadingLabel.text = "El universo"
    }
}

