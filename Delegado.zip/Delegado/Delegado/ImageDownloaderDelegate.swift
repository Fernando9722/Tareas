//
//  ImageDownloaderDelegate.swift
//  Delegado
//
//  Created by Usuario invitado on 24/10/18.
//

import Foundation
import UIKit

protocol ImageDownloaderDelegate {
    func didFinishDownload(_ sender: ImageDownloader)
}
