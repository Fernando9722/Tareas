//
//  GameScene.swift
//  SpaceInvaders
//
//  Created by Macbook on 11/7/18.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
    var spaceship = SKSpriteNode(imageNamed: "spaceship")

    override func didMove(to view: SKView) {
        spaceship.position = CGPoint(x: 375, y: -570)
        
        self.addChild(spaceship)
        
        var bulletTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (Timer) in
            let shot = SKSpriteNode(imageNamed: "shot")
            shot.zPosition = -1
            shot.position = CGPoint(x: self.spaceship.position.x, y: self.spaceship.position.y)
            
            let shotMoving = SKAction.moveTo(y: 1000, duration: 0.5)
            shot.run(SKAction.repeatForever(shotMoving))
            self.addChild(shot)
        }
        
        var enemyTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (Timer) in
            let alien = SKSpriteNode(imageNamed: "alien")
            alien.position = CGPoint(x: CGFloat(arc4random_uniform(750)), y: 700)
            
            let alienMoving = SKAction.moveTo(y: -1000, duration: 0.8)
            alien.run(SKAction.repeatForever(alienMoving))
            self.addChild(alien)
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch: AnyObject in touches {
            let location = touch.location(in: self)
            spaceship.position.x = location.x
        }
    }

}
